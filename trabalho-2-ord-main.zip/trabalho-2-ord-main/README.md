Segundo trabalho da disciplina de Organização e Recuperação de Dados. Implementação de uma arvore b para gerenciamento de registros. Operações implementadas: busca e inseção. 
